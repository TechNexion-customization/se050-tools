..
    Copyright 2019 NXP


=================================================
 SEMSLite Types and APIs
=================================================

.. contents::
    :backlinks: none
    :local:

.. _api-ref-sems_lite_agent_types:

SEMSLite Agent Types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. doxygengroup:: sems_lite_agent_types
    :no-link:
    :members:
    :protected-members:
    :private-members:
    :undoc-members:

.. _api-ref-sems_lite_agent:

SEMSLite Agent APIs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. doxygengroup:: sems_lite_agent
    :no-link:
    :members:
    :protected-members:
    :private-members:
    :undoc-members:

