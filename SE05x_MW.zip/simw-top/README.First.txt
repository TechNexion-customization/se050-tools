

Plug & Trust Middleware
================================================

Extensive Documentation is in doc\index.html / PlugAndTrustMW.pdf

Platform specific quick start guides are at:
- MCU/RTOS: https://www.nxp.com/docs/en/application-note/AN12396-Quick_start_guide_kinetis_k64.pdf
- MPU/Linux: https://www.nxp.com/docs/en/application-note/AN12397-Quick_start_guide_i.mx6ultralite.pdf
- Windows: https://www.nxp.com/docs/en/application-note/AN12398-Quick_start_guide_se050_vs_projects.pdf

More details regarding SE050 and other detailed application notes can be found at https://www.nxp.com/products/:SE050
