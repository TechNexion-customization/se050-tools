/* Copyright 2018 NXP
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef USE_CASE_H
#define USE_CASE_H

extern const char *gszA71COMPortDefault;
extern const char *gszA71SocketPortDefault;

#endif /* USE_CASE_H */
