
# Secure Sub System APIs.

Where applicable, Please Fork/clone this repository, rather than copying files.

The intention is to keep test cases and examples truely portabel.  In case they are not (due to some overisght), please file a ticket so that this can be addressed.


