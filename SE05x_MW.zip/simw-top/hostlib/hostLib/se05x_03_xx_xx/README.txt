
This folder is applicable to SE05X Applet Version 4.XX as well.
