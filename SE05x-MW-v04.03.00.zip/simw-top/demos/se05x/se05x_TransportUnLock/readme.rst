..
    Copyright 2019,2020 NXP



.. highlight:: bat

.. _transport-unlock:

=======================================================================
 SE05X Transport UnLock example
=======================================================================

This demo UnLocks SE05x applet, after it is locked by :numref:`transport-lock` :ref:`transport-lock`


.. warning:: This demo is just for reference for the usage of APIs,
             it should not be used for production.


See the corresponding demo :numref:`transport-lock` :ref:`transport-lock`

Both the lock and unlock demo use same key and common logic
from ``se05x_TransportAuth.c``
