..
    Copyright 2020 NXP




SEMS Lite DEMOs
========================


The DEMOs applicable to SEMS Lite are listed at
:numref:`demo-list-sems-lite` :ref:`demo-list-sems-lite`
