
See nxLog.h

Quick Guide:
    Run nxLog_Gen.py <NewCompnent> <ParentComponent>