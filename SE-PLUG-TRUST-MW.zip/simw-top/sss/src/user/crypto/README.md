A Project of Cryptography
---------------------------------------
This project implements AES, CMAC, SHA256, HMAC, RSA in C language.

The code is for demostration rather than production use.


--
From https://github.com/louk78/crypto_project/
