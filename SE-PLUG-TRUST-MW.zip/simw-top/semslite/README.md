
# Multi Cast Applet Loader

## Folders

doc : Documentation

lib : SEMS Lite as a Library / Re-usable code

lib/src : SEMS Lite Implementation

lib/inc : SEMS Lite Interface header files

tst : Tests

