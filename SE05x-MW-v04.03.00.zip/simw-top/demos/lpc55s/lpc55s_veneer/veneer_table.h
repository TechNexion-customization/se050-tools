/* Copyright 2019 NXP
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _VENEER_TABLE_H_
#define _VENEER_TABLE_H_

#include <veneer_printf_table.h>
#include <veneer_smcom_table.h>

#endif /* _VENEER_TABLE_H_ */
