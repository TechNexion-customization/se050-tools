/* Copyright 2019 NXP
 * SPDX-License-Identifier: Apache-2.0
 */

#include <ex_sss_objid.h>

/*Common KeyID for generating key pair*/
#define CERTIFICATE_KEY_ID (EX_SSS_OBJID_DEMO_CLOUD_START + 1)